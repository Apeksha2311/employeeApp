// console.log('test')

// show all data in table or dashbord

//http GET request to fetch all data from api
var tbody= document.getElementById('tbody')
var row = ''

axios.get('http://127.0.0.1:8000/api/emp/')
.then((resp)=>{
    var arr = resp.data;
    console.log(arr)
    for (var i = 0;i<arr.length;i++){

    row +=`
    <tr>
                    <td>${arr[i].name}</td>
                    <td>${arr[i].email}</td>
                    <td>${arr[i].contact}</td>
                    <td>${arr[i].address}</td>
                    <td>${arr[i].position}</td>
                    <td>${arr[i].company}</td>
                    <td>
                        <a href="" class="btn btn-success">Update</a>
                        <a href="" class="btn btn-danger">Delete</a>

                    </td>

                </tr>    `
    

    }
    tbody.innerHTML = row;

    

}).catch(()=>{
    alert('Something went Wrong..')
})

// post data section

var heading = document.getElementById('heading')

$('#post-btn').click(function(){
    $('#table-div').hide();
    $('#post-btn').hide();

    heading.innerHTML = 'Add Employee'

})
