// show all data in a table or dashboard 

// http GET request to fetch all data from api 

var tbody = document.getElementById('tbody')
var row = ''
$('#post-div').hide()


axios.get('http://127.0.0.1:8000/emp/')
.then((resp)=>{
    var arr = resp.data;
    console.log(arr)

    for (var i = 0 ; i<arr.length ; i++){
        row += `

            <tr>
                <td>${arr[i].name}</td>
                <td>${arr[i].email}</td>
                <td>${arr[i].contact}</td>
                <td>${arr[i].address}</td>
                <td>${arr[i].position}</td>
                <td>${arr[i].company}</td>
                <td>
                    <a href="#" class = "btn btn-success" onclick = "UpdateBtn('${arr[i].url}')">Update</a>
                    <a href="#" class = "btn btn-danger" onclick ="DeleteBtn('${arr[i].url}')">Delete</a>
                </td>
            </tr>

        `
    }
    tbody.innerHTML = row;

}).catch(()=>{
    alert('Something went wrong ;(')
})


// post data section 

var heading = document.getElementById('heading')

$('#post-btn').click(function(){
    $('#table-div').hide();
    $('#post-btn').hide();
    $('#post-div').show();

    heading.innerHTML = 'Add Employee'

})


// get data section 

function PostBtn(){
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var contact = document.getElementById('contact').value;
    var address = document.getElementById('address').value;
    var position = document.getElementById('position').value;
    var company = document.getElementById('company').value;


// covert field data into form data 
    var fd = new FormData();

    fd.append('name' , name)
    fd.append('email' , email);
    fd.append('contact' , contact);
    fd.append('address' , address);
    fd.append('position' , position);
    fd.append('company' , company);
    fd.append('csrfmiddlewaretoken' , '{{csrf_token}}');

// post data to api

    axios.post('http://127.0.0.1:8000/emp/' , fd)
    .then( () =>{
        alert('Employee Successfully Added..')
        window.location = 'index.html'

    }).catch( (err) =>{
        alert(err)
    })


}


// delete section 

function DeleteBtn(url){
    var x = confirm('Are you sure you want to delete..')

    if (x == true){
        // console.log(url)
        axios.delete(url).then( () =>{
            alert('Data Deleted..')
            window.location = 'index.html'

        }).catch( (err) =>{
            alert(err)
        })
    }
}

// update section 

function UpdateBtn(url){

    var heading = document.getElementById('heading');

    var update_div = document.getElementById('update-div');

    console.log(url)
    $('#table-div').hide()
    $('#post-btn').hide()

    heading.innerHTML = 'Update Employee'

    axios.get(url).then((resp) =>{
        var obj = resp.data;

        update_div.innerHTML = `

        <div class="container p-5 shadow rounded-3" style="width: 60%;">

            

        <!-- name input div  -->
        <div class="mb-3">
            <input type="text" name="uname" id="uname" placeholder="Update Employee Name" class="form-control" value="${obj.name}">
        </div>

        <!-- email input div  -->
        <div class="mb-3">
            <input type="email" name="uemail" id="uemail" placeholder="Update Employee Email" class="form-control" value="${obj.email}">
        </div>

        <!-- contact input div  -->
        <div class="mb-3">
            <input type="text" name="ucontact" id="ucontact" placeholder="Update Employee Contact" class="form-control" value="${obj.contact}">
        </div>

        <!-- address input div  -->
        <div class="mb-3">
            <input type="text" name="uaddress" id="uaddress" placeholder="Update Employee Address" class="form-control" value="${obj.address}">
        </div>

        <!-- position dropdown  -->

        <div class="mb-3">
            <select name="uposition" id="uposition" class="form-control" value="${obj.position}">
                <option value="developer">Developer</option>
                <option value="tester">Tester</option>
                <option value="manager">Manager</option>
            </select>
        </div>

        <!-- company input div  -->

        <div class="mb-3">
            <input type="text" name="ucompany" id="ucompany" placeholder="Update Company Name" class="form-control" value="${obj.company}">
        </div>

        <!-- add employee  -->
        <div class="mb-3">
            <input type="submit" value="Update Employee" class="btn btn-success" onclick="UpdateBtn()">
        </div>

    

</div>

        
        
        `

    }).catch( (err) =>{
        alert(err)
    })


}